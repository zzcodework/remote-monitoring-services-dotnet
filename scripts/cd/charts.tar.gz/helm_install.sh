#!/bin/bash

sh delete.sh
sleep 5
sh deploy.sh
